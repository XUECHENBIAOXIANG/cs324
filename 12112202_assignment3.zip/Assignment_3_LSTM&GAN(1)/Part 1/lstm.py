from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import torch
import torch.nn as nn
from torch import softmax


################################################################################

class LSTM(nn.Module):

    def __init__(self, seq_length, input_dim, hidden_dim, output_dim,batch_size,device):
        super(LSTM, self).__init__()
        # Initialization here ...

        self.seq_length = seq_length
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.batch_size = batch_size
        self.device = device
        self.Wgx = nn.Parameter(torch.randn(input_dim, hidden_dim))
        self.Whx = nn.Parameter(torch.randn(hidden_dim, hidden_dim))
        self.bg = nn.Parameter(torch.randn(hidden_dim))

        self.Wix = nn.Parameter(torch.randn(input_dim, hidden_dim))
        self.Whi = nn.Parameter(torch.randn(hidden_dim, hidden_dim))
        self.bi = nn.Parameter(torch.randn(hidden_dim))

        self.Wfx = nn.Parameter(torch.randn(input_dim, hidden_dim))
        self.Whf = nn.Parameter(torch.randn(hidden_dim, hidden_dim))
        self.bf = nn.Parameter(torch.randn(hidden_dim))

        self.Wox = nn.Parameter(torch.randn(input_dim, hidden_dim))
        self.Who = nn.Parameter(torch.randn(hidden_dim, hidden_dim))
        self.bo = nn.Parameter(torch.randn(hidden_dim))

        self.Wph = nn.Parameter(torch.randn(hidden_dim, output_dim))
        self.bp = nn.Parameter(torch.randn(output_dim))
        self.init_weights()

        self.h = torch.zeros(batch_size, self.hidden_dim).to(device)
        self.c = torch.zeros(batch_size, self.hidden_dim).to(device)

    def init_weights(self):
            for param in self.parameters():
                nn.init.uniform_(param, -0.1, 0.1)

    def forward(self, x):
        batch_size, seq_len, _ = x.size()
        h = self.h
        c = self.c

        for t in range(self.seq_length):
            xt = x[:, t, :]


            gt = torch.tanh(xt @ self.Wgx + h @ self.Whx + self.bg)
            it = torch.sigmoid(xt @ self.Wix + h @ self.Whi + self.bi)
            ft = torch.sigmoid(xt @ self.Wfx + h @ self.Whf + self.bf)
            ot = torch.sigmoid(xt @ self.Wox + h @ self.Who + self.bo)
            c = ft * c + it * gt
            h = ot * torch.tanh(c)
        p = h @ self.Wph + self.bp
        out = softmax(p, dim=1)
        return out

